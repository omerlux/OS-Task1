#include "types.h"
#include "stat.h"
#include "user.h"

#include "fcntl.h"

//passing command line arguments

int main(int argc, char *argv[])
{
    getpinfo();
    exit(0);
} 