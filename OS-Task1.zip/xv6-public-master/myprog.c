#include "types.h"
#include "stat.h"
#include "user.h"
    
 //passing command line arguments 
    
int main(int argc, char *argv[]) 
{ 
  printf(1, "HelloXV6\n");

  exit(0);
} 